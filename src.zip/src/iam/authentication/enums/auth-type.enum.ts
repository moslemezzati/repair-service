export enum AuthType {
  Bearer,
  None,
}
