export enum Role {
  ADMIN = 'admin',
  TECHNICIAN = 'technician',
  WORKER = 'worker',
}
